let classTempVentas = {
    
}